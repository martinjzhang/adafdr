# adafdr
## A fast and covariate-adaptive method for multiple hypothesis testing